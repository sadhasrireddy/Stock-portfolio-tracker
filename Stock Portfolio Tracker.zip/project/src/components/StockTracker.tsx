import React, { useState } from 'react';
import { TrendingUp, Plus, Trash2, Download, Calculator, DollarSign } from 'lucide-react';

interface Stock {
  id: number;
  name: string;
  quantity: number;
}

interface StockPrices {
  [key: string]: number;
}

const StockTracker: React.FC = () => {
  const [stocks, setStocks] = useState<Stock[]>([]);
  const [stockName, setStockName] = useState('');
  const [quantity, setQuantity] = useState('');

  // Hardcoded stock prices dictionary
  const stockPrices: StockPrices = {
    'AAPL': 180,
    'TSLA': 250,
    'GOOGL': 140,
    'MSFT': 350,
    'AMZN': 130,
    'META': 320,
    'NVDA': 450,
    'NFLX': 400,
    'AMD': 110,
    'INTC': 45
  };

  const addStock = () => {
    if (!stockName.trim() || !quantity.trim()) return;
    
    const upperStockName = stockName.toUpperCase();
    if (!stockPrices[upperStockName]) {
      alert(`Stock "${upperStockName}" not found in our database. Available stocks: ${Object.keys(stockPrices).join(', ')}`);
      return;
    }

    const newStock: Stock = {
      id: Date.now(),
      name: upperStockName,
      quantity: parseFloat(quantity)
    };

    setStocks(prev => [...prev, newStock]);
    setStockName('');
    setQuantity('');
  };

  const removeStock = (id: number) => {
    setStocks(prev => prev.filter(stock => stock.id !== id));
  };

  const calculateTotalValue = (): number => {
    return stocks.reduce((total, stock) => {
      const price = stockPrices[stock.name] || 0;
      return total + (stock.quantity * price);
    }, 0);
  };

  const calculateStockValue = (stock: Stock): number => {
    const price = stockPrices[stock.name] || 0;
    return stock.quantity * price;
  };

  const saveToTxt = () => {
    const totalValue = calculateTotalValue();
    let content = 'Stock Portfolio Summary\n';
    content += '========================\n\n';
    
    stocks.forEach(stock => {
      const price = stockPrices[stock.name];
      const value = calculateStockValue(stock);
      content += `${stock.name}: ${stock.quantity} shares @ $${price} = $${value.toFixed(2)}\n`;
    });
    
    content += `\nTotal Portfolio Value: $${totalValue.toFixed(2)}`;
    
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'portfolio.txt';
    a.click();
    URL.revokeObjectURL(url);
  };

  const saveToCsv = () => {
    const totalValue = calculateTotalValue();
    let content = 'Stock,Quantity,Price,Value\n';
    
    stocks.forEach(stock => {
      const price = stockPrices[stock.name];
      const value = calculateStockValue(stock);
      content += `${stock.name},${stock.quantity},${price},${value.toFixed(2)}\n`;
    });
    
    content += `Total,,,$${totalValue.toFixed(2)}`;
    
    const blob = new Blob([content], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'portfolio.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      addStock();
    }
  };

  const totalValue = calculateTotalValue();

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-600 to-blue-600 p-6 text-white">
        <div className="flex items-center space-x-3">
          <TrendingUp className="w-8 h-8" />
          <div>
            <h2 className="text-2xl font-bold">Stock Portfolio Tracker</h2>
            <p className="text-green-100">Track your investments with real-time calculations</p>
          </div>
        </div>
      </div>

      {/* Add Stock Form */}
      <div className="p-6 bg-gray-50 border-b border-gray-200">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Stock Symbol
            </label>
            <input
              type="text"
              value={stockName}
              onChange={(e) => setStockName(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="e.g., AAPL, TSLA, GOOGL"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
            />
          </div>
          <div className="flex-1">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Quantity
            </label>
            <input
              type="number"
              value={quantity}
              onChange={(e) => setQuantity(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Number of shares"
              min="0"
              step="0.01"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
            />
          </div>
          <div className="flex items-end">
            <button
              onClick={addStock}
              disabled={!stockName.trim() || !quantity.trim()}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex items-center space-x-2"
            >
              <Plus className="w-4 h-4" />
              <span>Add Stock</span>
            </button>
          </div>
        </div>
      </div>

      {/* Available Stocks Info */}
      <div className="p-4 bg-blue-50 border-b border-gray-200">
        <h3 className="text-sm font-medium text-gray-700 mb-2">Available Stocks:</h3>
        <div className="flex flex-wrap gap-2">
          {Object.entries(stockPrices).map(([symbol, price]) => (
            <span
              key={symbol}
              className="px-3 py-1 bg-white rounded-full text-xs font-medium text-gray-600 border border-gray-200"
            >
              {symbol}: ${price}
            </span>
          ))}
        </div>
      </div>

      {/* Portfolio List */}
      <div className="p-6">
        {stocks.length === 0 ? (
          <div className="text-center py-12">
            <TrendingUp className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-500 mb-2">No stocks added yet</h3>
            <p className="text-gray-400">Add your first stock to start tracking your portfolio</p>
          </div>
        ) : (
          <div className="space-y-4">
            {stocks.map((stock) => {
              const price = stockPrices[stock.name];
              const value = calculateStockValue(stock);
              
              return (
                <div
                  key={stock.id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-200 hover:shadow-md transition-all duration-200"
                >
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-blue-500 rounded-lg flex items-center justify-center">
                      <DollarSign className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-800">{stock.name}</h4>
                      <p className="text-sm text-gray-600">
                        {stock.quantity} shares @ ${price}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <p className="font-bold text-lg text-green-600">
                        ${value.toFixed(2)}
                      </p>
                    </div>
                    <button
                      onClick={() => removeStock(stock.id)}
                      className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-all duration-200"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Total Value & Actions */}
      {stocks.length > 0 && (
        <div className="p-6 bg-gray-50 border-t border-gray-200">
          <div className="flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0">
            <div className="flex items-center space-x-3">
              <Calculator className="w-6 h-6 text-green-600" />
              <div>
                <p className="text-sm text-gray-600">Total Portfolio Value</p>
                <p className="text-2xl font-bold text-green-600">
                  ${totalValue.toFixed(2)}
                </p>
              </div>
            </div>
            
            <div className="flex space-x-3">
              <button
                onClick={saveToTxt}
                className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-all duration-200 flex items-center space-x-2"
              >
                <Download className="w-4 h-4" />
                <span>Save as TXT</span>
              </button>
              <button
                onClick={saveToCsv}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 focus:ring-2 focus:ring-green-500 focus:ring-offset-2 transition-all duration-200 flex items-center space-x-2"
              >
                <Download className="w-4 h-4" />
                <span>Save as CSV</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StockTracker;