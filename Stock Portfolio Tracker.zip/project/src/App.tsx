import React from 'react';
import StockTracker from './components/StockTracker';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-800 mb-2">Stock Portfolio Tracker</h1>
            <p className="text-lg text-gray-600">Track your investments and calculate portfolio value</p>
          </div>

          {/* Stock Tracker Container */}
          <div className="min-h-[600px]">
            <StockTracker />
          </div>

          {/* Instructions */}
          <div className="mt-8 bg-white rounded-lg shadow-sm p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-3">How to use the tracker:</h3>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-green-600 font-medium mb-1">Add Stocks</div>
                <div className="text-sm text-gray-600">Enter stock symbol and quantity</div>
              </div>
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-blue-600 font-medium mb-1">View Portfolio</div>
                <div className="text-sm text-gray-600">See total investment value</div>
              </div>
              <div className="text-center p-4 bg-purple-50 rounded-lg">
                <div className="text-purple-600 font-medium mb-1">Export Data</div>
                <div className="text-sm text-gray-600">Save as TXT or CSV file</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;